$(document).ready(function(){
    $("#visa").click(function(){
        $("#method").val("visa");
    });
    
    $("#master").click(function(){
        $("#method").val("master");
    });
    
    $("#paypal").click(function(){
        $("#method").val("paypal");
    });
});
