@extends('layouts.customer')

@section('content')


<div class="container">

<div class="col-md-12" style="height:500px;">
{!! Mapper::render() !!}
</div>


<br>

<h4> <i class="fas fa-map"></i> Address : No 198, 164 Street, Tarmwae Township Yangon</h4>
<br>
<h4> <i class="fas fa-phone"></i> Phone : 09966636117</h4>
<br>
<h4> <i class="fas fa-envelope"></i> Email : browsingbooks@gmail.com</h4>
<br>
<h2>About Us</h2>
<p>This Online book selling websites helps to buy the books online with Recommendation system  which is one of the stronger tools to increase profit  and retaining buyer.  The book recommendation system must recommend books that are of buyer’s interest.  Recommendation systems are widely used to recommend products  to the end users that are most appropriate.   This system saves the precious time of customer and very efficient to use. Provides large number of choices for books & also recommend for books.  User can buy book easily by making online ordering  After Successful Login user can see all the available books to buy online
If User can’t connect from Website, can order from Facebook page
can login with facebook account.
</p>
<br>

</div>

@endsection