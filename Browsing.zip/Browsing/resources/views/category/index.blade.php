@extends('layouts/app')

@section('content')
  <div class="container">
    <h3>Category List</h3>

    @if(session('alert'))
    <div class="alert alert-info">
      {{ session('alert') }}
    </div>
    @endif
    <table class="table table-bordered table-striped">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Total Books</th>

      </tr>
      @foreach($categories as $category)
        <tr>
          <td>{{ $category->id }}</td>
          <td>{{ $category->name}}</td>
          <td>{{count($category->books)}}</td>

        </tr>
      @endforeach
    </table>
    <a href="{{ url('admin/categories/add') }}"><button class="btn btn-primary">Add New Category</button></a>
  </div>
@endsection