@extends('layouts.customer')

@section('content')

<div class="container">
@if(session('alert'))
    <div class="alert alert-info">
      {{ session('alert') }}
    </div>
    @endif
<h1>Books in Your Bag</h1>
<br>
<div class="row" >
@php
    $total=0;
@endphp
    @foreach($books as $book)
        <div class="col-md-3" style="height:500px;" align="center">
        
        
            <div> 
                <div id="book-holder" align="center">
                <img src="{{asset("img/$book->photo")}}" width="100%" height="90%"/>
                </div>
            </div>

            <div align="center" style="background-color:cornflowerblue;">
            @foreach(Session::get('bag') as $bag)
                            @if($book->id==$bag['id'])
                            @php
                           $bagid = $bag['id'];
                           @endphp
            <form class="form-inline" method="post" action="{{url('user/addbag')}}"> 
            {{csrf_field()}}
            <div class="form-group">  
            <a href="{{url("user/minusbag/$bagid")}}" class="btn btn-secondary" style="color:white;border-radius:0;background-color:#333;border-color:#333;">-</a>
            &nbsp;&nbsp;&nbsp;&nbsp;{{$bag['qty']}} &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="hidden" value="{{$bagid}}" name="id"/>
            <input type="hidden" value="1" name="qty"/>
            <input type="submit" class="btn btn-secondary" style="border-radius:0;background-color:#333;border-color:#333" value="+"/>
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;<b>{{$book->price*$bag['qty']}} ks</b>
            </form>
            @php
            $total +=$book->price*$bag['qty']
            @endphp
                            @endif
                @endforeach
            </div>
        </div>
    @endforeach
</div>
<hr>
<div class="row">
<div class="col-md-6">
    <h3>Total Price : {{$total}} ks</h3>
    <br>
    <h4>Availabel Methods</h4>
    <div id="visa">
    <img src="{{asset('img/visacard.png')}}" width="180" height="100"/>
    </div>
    <br><br>
    <div id="master">
    <img src="{{asset('img/mastercard.png')}}" width="180" height="100"/>
    </div>
    <br><br>
    <img src="{{asset('img/paypalcard.png')}}" width="180" height="100" id="paypal"/>
</div>
<div class="col-md-6">
<h3>Check Out</h3>
    <form method="post" action="{{url('user/order')}}">
    {{csrf_field()}}
        <div class="form-group">
            <label>Payment</label>
            <select class="form-control" name="payment">
                <option value="visa">Visa</option>
                <option value="master">Master</option>
                <option value="paypal">Paypal</option>
            </select> 
        </div>
        <div class="form-group">
            <label>Code</label>
            <input type="text" name="code"  class="form-control" required/>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" required/>
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" class="form-control" required/>
        </div>
        <input type="submit" value="Check Out" class="btn btn-primary"/>
    </form>

</div>
</div>
</div>


@endsection
