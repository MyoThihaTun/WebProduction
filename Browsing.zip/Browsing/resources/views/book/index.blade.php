@extends('layouts/app')

@section('content')


  <div class="container">
    <h3>Book List</h3>

    @if(session('alert'))
    <div class="alert alert-info">
      {{ session('alert') }}
    </div>
    @endif
    <table class="table table-bordered table-striped">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Author</th>
        <th>Price</th>
        <th>Status</th>
      </tr>
      @foreach($books as $book)
        <tr>
          <td>{{ $book->id }}</td>
          <td><a href="{{ url('admin/books/view/'.$book->id) }}">
                  {{ $book->name }}
                  </a>
          </td>
          <td>{{$book->category->name}}</td>
          <td>{{$book->author}}</td>
          <td>{{$book->price}}</td>          
          <td>
            @if($book->isrecommended==0)
            <div class="badge badge-danger">Common</div>
            @else
            <div class="badge badge-primary">Recommended</div>
            @endif
          </td>
        </tr>
      @endforeach
    </table>
	<a href="{{ url('admin/books/add') }}"><button class="btn btn-primary">Add New Book</button></a>
  </div>

@endsection