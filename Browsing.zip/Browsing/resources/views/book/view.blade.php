@extends('layouts/app')

@section('content')

<div class="container">

<div class="row">
    <div class="col-md-4">
        <img src="{{asset("img/$book->photo")}}" width="80%" height="400"/>
    </div>
    <div class="col-md-8">
    <h1>{{$book->name}}</h1>
    <br>
    <h5>{{$book->description}}</h5>
    <br>
    <h5><b>Price : {{$book->price}}</b></h5>
    <br>
    <h5>Current Status : @if($book->isrecommended==0) <div class="badge badge-danger"> Common </div> @else <div class="badge badge-primary">Recommended</div>@endif  </h5>
    <br>
    @if($book->isrecommended==0)
    <a href="{{url("admin/books/recommend/$book->id")}}" class="btn btn-primary" style="color:white">Recommend This Book <i class="fas fa-check"></i> </a>
    @else
    <a href="{{url("admin/books/disrecommend/$book->id")}}" class="btn btn-danger" style="color:white">Cancel Recommendation <i class="fas fa-times"></i></a>
    @endif
    </div>
</div>

</div>

@endsection