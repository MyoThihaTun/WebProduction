@extends('layouts/app')

@section('content')

<div class="container">
  <div class="col-lg-offset-3 col-lg-6">
    <h3>Add New Book</h3>
    @if( $errors->any() )
    <div class="alert alert-warning">
      @foreach($errors->all() as $error)
        {{ $error }}
      @endforeach
    </div>
    @endif

    <form  method="post" enctype="multipart/form-data">
      {{ csrf_field() }}
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control"  required autofocus>
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <input type="text" name="description" class="form-control">
      </div>
      <div class="form-group">
        <label for="category_id">Category</label>
        <select name="category_id" class="form-control">
            @foreach($categories as $category)
            <option value="{{$category->id}}">{{$category->name}}</option>
            @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="author">Author</label>
        <input type="text" name="author" class="form-control">
      </div>
      <div class="form-group">
        <label for="price">Price</label>
        <input type="text" name="price" class="form-control">
      </div>
      <div class="form-group">
        <label for="photo">Photo</label>
        <input type="file" name="photo" class="form-control">
      </div>
        <input type="submit" value="Add New Book" class="btn btn-primary">
      
    </form>

  </div>

</div>

@endsection