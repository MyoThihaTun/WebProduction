@extends('layouts/customer')

@section('content')

<div class="container">
<br>
<div class="row">

    <div class="col-md-4">
        <img src="{{asset("img/$book->photo")}}" width="80%" height="400"/>
    </div>
    <div class="col-md-8">
    <h1><i class="fas fa-book-open"></i> {{$book->name}}</h1>
    <br>
    <h5><i class="fas fa-list"></i> {{$book->description}}</h5>
    <br>
    <h5><b><i class="fas fa-credit-card"></i> Price : {{$book->price}}</b></h5>
    <br>
    <h5>Total Purchases : {{count($book->orderdetails)}} </h5>
    <br>
    <form method="post" action="{{url('user/addbag/')}}">
    {{csrf_field()}}
    <input type="hidden" name="id" value="{{$book->id}}"/>
    <input type="hidden" name="qty" value="1"/>
    <input type="submit" class="btn btn-primary" value="Add to Bag"/>
    </form
    </div>
</div>

</div>
<hr>
@endsection