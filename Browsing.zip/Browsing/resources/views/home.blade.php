@extends('layouts.customer')

@section('content')

<div class="container">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img class="d-block w-100" src="{{asset('img/slide1.jpg')}}" alt="First slide" width="100%" height="600px;">
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="{{asset('img/slide2.jpg')}}" alt="First slide" width="100%" height="600px;">
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="{{asset('img/slide3.jpg')}}" alt="First slide" width="100%" height="600px;">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    </div>
</div>
<br><br>
<div class="container">
<div class="row">
    <div class="col-md-3" style="background-color:white">
        <h4>Search</h4>
        <div class="input-group mb-4">
        <form method="post" action="{{url('user/search/')}}" class="form-inline">
        {{csrf_field()}}
        <div class="form-group">
        <input type="text" name="name" class="form-control" placeholder="Books" aria-label="Recipient's username" aria-describedby="button-addon2" required>
        <div class="input-group-append">
            <input type="submit" class="btn btn-primary" type="button" id="button-addon2" style="background-color:cornflowerblue" value="Search"/>
        </div>
        </div>
        </form>
        </div>
        <hr>
        <h4>Top Categories</h4>
        <div style="margin-left:10px;font-size:18px;">
        @foreach($categories as $category)
        <div class="badge badge-primary" style="background-color:cornflowerblue"> {{$category->name}} </div>
        @endforeach
        </div>
        <hr>
        <h4>Payment Methods<h4>
        <div style="margin-left:10px;width:100%;margin-right:10px;">
        <img src="{{asset("img/visa.jpg")}}" height="120" width="80%"/><br>
        <img src="{{asset("img/master.jpg")}}" height="120" width="80%"/><br>
        <img src="{{asset("img/paypal.jpg")}}" height="120" width="80%"/>
        </div>
    </div>
    
    <div class="col-md-8" >
    <div class="row">
    @foreach($books as $book)
        <div class="col-md-4" style="height:400px;">
        
        
           <div style="background-size:cover;background-position:center;width:100%height:90%;background-image:url({{asset("img/$book->photo")}})"> 
           <div id="book-holder" align="center" >
                <br>
                    
                <br><br>  <br><br> <br><br> <br><br> 
                <br><br>
                <a href="{{url('user/detail/'.$book->id)}}" class="btn btn-primary">Details <i class="fas fa-eye"></i></a> 
                <br><br><br>
                </div>
            </div>
        
        
        </div>
    @endforeach
        {{$books->links()}}
    </div>
    </div>
</div>
</div>


@endsection
