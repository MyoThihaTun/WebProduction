<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('authcheck:admin');
    }

    public function index()
    {
        $categories = Category::all();
        return view('category/index',['categories'=>$categories]);
    }

    public function add()
    {
        return view('category/add');
    }

    public function create()
    {
        $category = new Category();
        $category->name = request()->name;
        $category->save();

        return redirect('admin/categories')->with('alert','Category Added');
    }

    public function edit()
    {
        $category = Category::find($id);
        return view('category/edit',['category'=>$category]);
    }

    public function update($id)
    {
        $category = Category::find($id);
        $category->name = request()->name;

        $category->save();

        return redirect('admin/categories')->with('alert','Category Updated');
    }

    public function delete($id)
    {
        $category = Category::find($id);
        $category->delete();

        return redirect('admin/categories')->with('alert','Category Deleted');
    }
}
