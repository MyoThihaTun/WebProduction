<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Book;
use Mapper;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books = Book::paginate(9);
        $categories = Category::all();
        return view('home',['books'=>$books,'categories'=>$categories]);
    }

    public function recommendations()
    {
        $books = Book::where('isrecommended',1)->get();
        return view('recommendation',['books'=>$books]);
    }

    public function location()
    {
        Mapper::map(16.811855, 96.173860);

        return view('contact');
    }

    public function search()
    {
        $name = request()->name;

        $books = Book::where('name', 'LIKE', '%'.$name.'%')->paginate(9);
        $categories = Category::all();
        return view('home',['books'=>$books,'categories'=>$categories]);
    }

    public function view($id)
    {
        $book = Book::find($id);
        return view('detail',['book'=>$book]);
    }
}
