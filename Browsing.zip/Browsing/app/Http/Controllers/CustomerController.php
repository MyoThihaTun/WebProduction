<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\Book;
use Illuminate\Support\Collection;
use App\Order;
use Illuminate\Support\Facades\Auth;
use App\Orderdetail;

class CustomerController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('authcheck:user');
    }
    public function showbag()
    {
        $bags = session()->get('bag');
        $booksfrombags = new Collection();
        if($bags)
        {
            
            foreach($bags as $bag)
        {
            $books = Book::where("id", $bag["id"])->get();
            $booksfrombags = $booksfrombags->merge($books);
        }
       
        }
        return view('/bag',['books'=>$booksfrombags]);
    }

    public function addtobag()
    {
        $id = request()->id;
        $qty = request()->qty;
        $issame = false;
        $bags = session()->get('bag');
        $newbag = [];
        $item = [
            'id' => $id,
            'qty' => $qty
          ];
        if($bags==[])
        {
            Session::push('bag', $item);
            $issame=true;
        }
        else
        {
            foreach($bags as $bag)
            {
                if($bag["id"]==$id)
                    {
                        $bag["qty"] += $qty;
                        $newbag[] = [
                            'id'=>$bag['id'],
                            'qty' => $bag['qty']
                        ];
                        $issame=true;
                    }
                else
                    {
                        $newbag[] = [
                            'id'=>$bag['id'],
                            'qty' => $bag['qty']
                        ];
                    }  
           
            }
            Session::put('bag', $newbag);
            if($issame==false)
            {
                Session::push('bag', $item);
            }
        }
        return back();
    }

    public function minusbag($id)
    {
        $bags = session()->get('bag');
        $newbag = [];
        foreach($bags as $bag)
            {
                if($bag["id"]==$id)
                    {
                        if($bag["qty"]==1)
                        {

                        }
                        else
                        {
                        $bag["qty"] -= 1;
                        $newbag[] = [
                            'id'=>$bag['id'],
                            'qty' => $bag['qty']
                        ];
                        }
                     
                    }
                else
                    {
                        $newbag[] = [
                            'id'=>$bag['id'],
                            'qty' => $bag['qty']
                        ];
                    }  
           
            }
            Session::put('bag', $newbag);
            return back();
    }

    public function order()
    {
        $bags = session()->get('bag');
        if($bags)
        {
            if(count($bags)>0)
            {
                $validator = validator(request()->all(),[
                    "address"=>"required",
                    "phone"=>"numeric | min:5",
                    "payment"=>"required",
                    "code"=>"required"
        
                  ]);
                  if ($validator->fails()) {
                    return back()->with('alert','Please fill valid data');
                  }

                  $totalprice = 0;
                  $totalqty = 0;

                  $order = new Order();
                  $order->user_id = auth::user()->id;
                  $order->address = request()->address;
                  $order->phone = request()->phone;
                  $order->payment = request()->payment;
                  $order->code = request()->code;

                  $order->save();
  
                  foreach($bags as $bag)
                  {
                      $orderdetail = new Orderdetail();
                      $orderdetail->order_id = $order->id;
                      $orderdetail->book_id = $bag['id'];
                      $orderdetail->qty = $bag['qty'];
                      $book = Book::find($bag['id']);
                      $orderdetail->totalprice = $book->price*$bag['qty'];
                      $orderdetail->save();
  
                      $totalprice += $orderdetail->amount;

                      $totalqty += $orderdetail->qty;
  
                  }
  
                  $ord = Order::find($order->id);
                  $ord->totalqty = $totalqty;
                  $ord->totalprice = $totalprice;
                  $ord->save();

                  Session::forget('bag');
                
                return back()->with('alert','Successfully Purchased');
            }

            return back()->with('alert','Please add books to your bag');
        }
        return back()->with('alert','Please add books to your bag');
    }
}
