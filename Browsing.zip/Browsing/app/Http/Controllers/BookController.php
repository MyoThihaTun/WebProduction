<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Book;
use App\Category;

class BookController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('authcheck:admin');
    }

    public function index()
    {
        $books = Book::all();
        return view('book/index',['books'=>$books]);
    }

    public function view($id)
    {
        $book = Book::find($id);
        return view('book/view',['book'=>$book]);
    }

    public function add()
    {
        $categories = Category::all();
        return view('book/add',['categories'=>$categories]);
    }

    public function create()
    {
        $validator = validator(request()->all(),[
            "name"=>"required | min:3",
            "description"=>"required ",
            "category_id"=>"required",
            "author"=>"required",
            "price"=>"numeric | min:3",

          ]);
          if ($validator->fails()) {
            return back()->witherrors('Please fill valid data');
          }
        
        $book = new Book();
        $book->name = request()->name;
        $book->description = request()->description;
        $book->category_id = request()->category_id;
        $book->author = request()->author;
        $book->price = request()->price;
        $imageName = time().'.'.request()->photo->getClientOriginalExtension();
        request()->photo->move(public_path('img'), $imageName);
        $book->photo = $imageName;
        $book->save();
        
        return redirect('admin/books/')->with('alert','Book Added');
        
    }

    public function delete($id)
    {
        $book = Book::find($id);
        $book->delete();

        return redirect('admin/books/')->with('alert','Book Deleted');
    }

    public function edit($id)
    {
        $book = Book::find($id);
        
        return view('book/edit',['book'=>$book]);
    }

    public function update($id)
    {
        $book = Book::find($id);
        $book->name = request()->name;
        $book->description = request()->description;
        $book->category_id = request()->category_id;
        $book->author = request()->author;
        $book->price = request()->price;
        $book->save();

        return redirect('admin/books/')->with('alert','Book Updated');
    }

    public function recommend($id)
    {
        $book = Book::find($id);
        $book->isrecommended = 1;

        $book->save();

        return back();
    }

    public function disrecommend($id)
    {
        $book = Book::find($id);
        $book->isrecommended = 0;

        $book->save();

        return back();
    }

    public function recommendations()
    {
        $books = Book::where('isrecommended',1)->get();
        return view('book/index',['books'=>$books]);
    }
}
