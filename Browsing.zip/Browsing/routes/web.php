<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('admin/','BookController@index');
Route::get('admin/books/','BookController@index');
Route::get('admin/books/view/{id}','BookController@view');
Route::get('admin/books/add','BookController@add');
Route::post('admin/books/add','BookController@create');
Route::get('admin/books/delete/{id}','BookController@delete');
Route::get('admin/books/recommendations','BookController@recommendations');
Route::get('admin/books/recommend/{id}','BookController@recommend');
Route::get('admin/books/disrecommend/{id}','BookController@disrecommend');

Route::get('admin/categories','CategoryController@index');
Route::get('admin/categories/add','CategoryController@add');
Route::post('admin/categories/add','CategoryController@create');


Route::get('user/','HomeController@index');
Route::get('user/books','HomeController@index');
Route::get('user/recommendations','HomeController@recommendations');
Route::get('user/contact','HomeController@location');
Route::post('user/addbag','CustomerController@addtobag');
Route::get('user/bag','CustomerController@showbag');
Route::get('user/minusbag/{id}','CustomerController@minusbag');
Route::post('user/order','CustomerController@order');
Route::post('user/search','HomeController@search');
Route::get('user/detail/{id}','HomeController@view');


Route::get('/redirect', 'SocialAuthFacebookController@redirect');
Route::get('/callback', 'SocialAuthFacebookController@callback');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/', 'HomeController@index')->name('home');
