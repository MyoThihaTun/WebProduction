<?php $__env->startSection('content'); ?>

<div class="container">
<h1>All recommended books</h1>
<br>
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
<div class="col-md-1"></div>
    <div class="col-md-3">
        <img src="<?php echo e(asset("img/$book->photo")); ?>" width="80%" height="300"/>
    </div>
    <div class="col-md-7">
    <h3><b><i class="fas fa-award"></i> <?php echo e($book->name); ?> <?php if($book->isrecommended==0): ?> <div class="badge badge-danger"> Common </div> <?php else: ?> <div class="badge badge-primary">Recommended</div><?php endif; ?></b></h3>
    <br>
    <h6><i class="fas fa-book-open"></i> <?php echo e($book->description); ?></h6>
    <br>
    <h6><b><i class="far fa-credit-card"></i> Price : <?php echo e($book->price); ?></b></h6>
    <br>
    <form method="post" action="<?php echo e(url('user/addbag/')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($book->id); ?>"/>
    <input type="hidden" name="qty" value="1"/>
    <button type="submit" class="btn btn-primary" style="background-color:cornflowerblue">Add to bag <i class="fas fa-shopping-bag"></i></button>
    </form>
    <br>
    
    </div>
</div>
<div class="col-md-1"></div>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>