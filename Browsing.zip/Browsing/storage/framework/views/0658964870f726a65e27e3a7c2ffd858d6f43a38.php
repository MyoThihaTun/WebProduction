<?php $__env->startSection('content'); ?>

<div class="container">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e(asset('img/slide1.jpg')); ?>" alt="First slide" width="100%" height="600px;">
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(asset('img/slide2.jpg')); ?>" alt="First slide" width="100%" height="600px;">
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(asset('img/slide3.jpg')); ?>" alt="First slide" width="100%" height="600px;">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    </div>
</div>
<br><br>
<div class="container">
<div class="row">
    <div class="col-md-3" style="background-color:white">
        <h4>Search</h4>
        <div class="input-group mb-4">
        <form method="post" action="<?php echo e(url('user/search/')); ?>" class="form-inline">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
        <input type="text" name="name" class="form-control" placeholder="Books" aria-label="Recipient's username" aria-describedby="button-addon2" required>
        <div class="input-group-append">
            <input type="submit" class="btn btn-primary" type="button" id="button-addon2" style="background-color:cornflowerblue" value="Search"/>
        </div>
        </div>
        </form>
        </div>
        <hr>
        <h4>Top Categories</h4>
        <div style="margin-left:10px;font-size:18px;">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="badge badge-primary" style="background-color:cornflowerblue"> <?php echo e($category->name); ?> </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <h4>Payment Methods<h4>
        <div style="margin-left:10px;width:100%;margin-right:10px;">
        <img src="<?php echo e(asset("img/visa.jpg")); ?>" height="120" width="80%"/><br>
        <img src="<?php echo e(asset("img/master.jpg")); ?>" height="120" width="80%"/><br>
        <img src="<?php echo e(asset("img/paypal.jpg")); ?>" height="120" width="80%"/>
        </div>
    </div>
    
    <div class="col-md-8" >
    <div class="row">
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4" style="height:400px;">
        
        
           <div style="background-size:cover;background-position:center;width:100%height:90%;background-image:url(<?php echo e(asset("img/$book->photo")); ?>)"> 
           <div id="book-holder" align="center" >
                <br>
                    
                <br><br>  <br><br> <br><br> <br><br> 
                <br><br>
                <a href="<?php echo e(url('user/detail/'.$book->id)); ?>" class="btn btn-primary">Details <i class="fas fa-eye"></i></a> 
                <br><br><br>
                </div>
            </div>
        
        
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($books->links()); ?>

    </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>