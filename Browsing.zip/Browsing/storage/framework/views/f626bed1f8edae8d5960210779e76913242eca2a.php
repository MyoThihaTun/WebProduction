<?php $__env->startSection('content'); ?>


  <div class="container">
    <h3>Book List</h3>

    <?php if(session('alert')): ?>
    <div class="alert alert-info">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
    <table class="table table-bordered table-striped">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Author</th>
        <th>Price</th>
        <th>Status</th>
      </tr>
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($book->id); ?></td>
          <td><a href="<?php echo e(url('admin/books/view/'.$book->id)); ?>">
                  <?php echo e($book->name); ?>

                  </a>
          </td>
          <td><?php echo e($book->category->name); ?></td>
          <td><?php echo e($book->author); ?></td>
          <td><?php echo e($book->price); ?></td>          
          <td>
            <?php if($book->isrecommended==0): ?>
            <div class="badge badge-danger">Common</div>
            <?php else: ?>
            <div class="badge badge-primary">Recommended</div>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
	<a href="<?php echo e(url('admin/books/add')); ?>"><button class="btn btn-primary">Add New Book</button></a>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>