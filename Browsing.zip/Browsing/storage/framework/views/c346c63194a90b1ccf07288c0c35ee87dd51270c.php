<?php $__env->startSection('content'); ?>

<div class="container">
<br>
<div class="row">

    <div class="col-md-4">
        <img src="<?php echo e(asset("img/$book->photo")); ?>" width="80%" height="400"/>
    </div>
    <div class="col-md-8">
    <h1><i class="fas fa-book-open"></i> <?php echo e($book->name); ?></h1>
    <br>
    <h5><i class="fas fa-list"></i> <?php echo e($book->description); ?></h5>
    <br>
    <h5><b><i class="fas fa-credit-card"></i> Price : <?php echo e($book->price); ?></b></h5>
    <br>
    <h5>Total Purchases : <?php echo e(count($book->orderdetails)); ?> </h5>
    <br>
    <form method="post" action="<?php echo e(url('user/addbag/')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($book->id); ?>"/>
    <input type="hidden" name="qty" value="1"/>
    <input type="submit" class="btn btn-primary" value="Add to Bag"/>
    </form
    </div>
</div>

</div>
<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>