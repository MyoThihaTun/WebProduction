<?php $__env->startSection('content'); ?>

<div class="container">

<div class="row">
    <div class="col-md-4">
        <img src="<?php echo e(asset("img/$book->photo")); ?>" width="80%" height="400"/>
    </div>
    <div class="col-md-8">
    <h1><?php echo e($book->name); ?></h1>
    <br>
    <h5><?php echo e($book->description); ?></h5>
    <br>
    <h5><b>Price : <?php echo e($book->price); ?></b></h5>
    <br>
    <h5>Current Status : <?php if($book->isrecommended==0): ?> <div class="badge badge-danger"> Common </div> <?php else: ?> <div class="badge badge-primary">Recommended</div><?php endif; ?>  </h5>
    <br>
    <?php if($book->isrecommended==0): ?>
    <a href="<?php echo e(url("admin/books/recommend/$book->id")); ?>" class="btn btn-primary" style="color:white">Recommend This Book <i class="fas fa-check"></i> </a>
    <?php else: ?>
    <a href="<?php echo e(url("admin/books/disrecommend/$book->id")); ?>" class="btn btn-danger" style="color:white">Cancel Recommendation <i class="fas fa-times"></i></a>
    <?php endif; ?>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>