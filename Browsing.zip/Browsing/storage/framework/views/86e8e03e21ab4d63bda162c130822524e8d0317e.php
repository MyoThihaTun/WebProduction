<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="col-lg-offset-3 col-lg-6">
    <h3>Add New Book</h3>
    <?php if( $errors->any() ): ?>
    <div class="alert alert-warning">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <form  method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control"  required autofocus>
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <input type="text" name="description" class="form-control">
      </div>
      <div class="form-group">
        <label for="category_id">Category</label>
        <select name="category_id" class="form-control">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="author">Author</label>
        <input type="text" name="author" class="form-control">
      </div>
      <div class="form-group">
        <label for="price">Price</label>
        <input type="text" name="price" class="form-control">
      </div>
      <div class="form-group">
        <label for="photo">Photo</label>
        <input type="file" name="photo" class="form-control">
      </div>
        <input type="submit" value="Add New Book" class="btn btn-primary">
      
    </form>

  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>